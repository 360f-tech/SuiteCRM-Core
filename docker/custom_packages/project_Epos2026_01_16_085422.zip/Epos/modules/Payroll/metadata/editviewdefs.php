<?php
$module_name = 'EPOS_Payroll';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 'assigned_user_name',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'bank_account_holder_name',
            'label' => 'LBL_BANK_ACCOUNT_HOLDER_NAME',
          ),
          1 => 
          array (
            'name' => 'bank_account_number',
            'label' => 'LBL_BANK_ACCOUNT_NUMBER',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'employer_name',
            'label' => 'LBL_EMPLOYER_NAME',
          ),
          1 => 
          array (
            'name' => 'employer_mobile',
            'label' => 'LBL_EMPLOYER_MOBILE',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'employee_payroll_number',
            'label' => 'LBL_EMPLOYEE_PAYROLL_NUMBER',
          ),
          1 => '',
        ),
        4 => 
        array (
          0 => 'description',
        ),
      ),
    ),
  ),
);
