<?php
$module_name = 'EPOS_Payroll';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '30%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'BANK_ACCOUNT_HOLDER_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_BANK_ACCOUNT_HOLDER_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'BANK_ACCOUNT_NUMBER' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_BANK_ACCOUNT_NUMBER',
    'width' => '10%',
    'default' => true,
  ),
  'EMPLOYER_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EMPLOYER_NAME',
    'width' => '20%',
    'default' => true,
  ),
  'EMPLOYEE_PAYROLL_NUMBER' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EMPLOYEE_PAYROLL_NUMBER',
    'width' => '20%',
    'default' => true,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => true,
  ),
  'EMPLOYER_MOBILE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EMPLOYER_MOBILE',
    'width' => '10%',
    'default' => false,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '10%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => false,
  ),
);
