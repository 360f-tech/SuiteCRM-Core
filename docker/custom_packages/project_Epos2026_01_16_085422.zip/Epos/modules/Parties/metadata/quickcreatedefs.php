<?php
$module_name = 'EPOS_Parties';
$viewdefs [$module_name] = 
array (
  'QuickCreate' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => true,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => true,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => true,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL2' => 
        array (
          'newTab' => true,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 'assigned_user_name',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'title',
            'label' => 'LBL_TITLE',
          ),
          1 => 
          array (
            'name' => 'email',
            'label' => 'LBL_EMAIL',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'first_name',
            'label' => 'LBL_FIRST_NAME',
          ),
          1 => 
          array (
            'name' => 'last_name',
            'label' => 'LBL_LAST_NAME',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'middle_name',
            'label' => 'LBL_MIDDLE_NAME',
          ),
          1 => 
          array (
            'name' => 'alternate_name',
            'label' => 'LBL_ALTERNATE_NAME',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'is_smoker',
            'label' => 'LBL_IS_SMOKER',
          ),
          1 => 
          array (
            'name' => 'gender',
            'studio' => 'visible',
            'label' => 'LBL_GENDER',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'date_of_birth',
            'label' => 'LBL_DATE_OF_BIRTH',
          ),
          1 => 
          array (
            'name' => 'marital_status',
            'studio' => 'visible',
            'label' => 'LBL_MARITAL_STATUS',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'nationality',
            'label' => 'LBL_NATIONALITY',
          ),
          1 => 
          array (
            'name' => 'other_nationality',
            'label' => 'LBL_OTHER_NATIONALITY',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'identification_type',
            'studio' => 'visible',
            'label' => 'LBL_IDENTIFICATION_TYPE',
          ),
          1 => 
          array (
            'name' => 'identification_number',
            'label' => 'LBL_IDENTIFICATION_NUMBER',
          ),
        ),
        8 => 
        array (
          0 => 
          array (
            'name' => 'country_of_birth',
            'label' => 'LBL_COUNTRY_OF_BIRTH',
          ),
          1 => 
          array (
            'name' => 'fatca_social_security_number',
            'label' => 'LBL_FATCA_SOCIAL_SECURITY_NUMBER',
          ),
        ),
        9 => 
        array (
          0 => 
          array (
            'name' => 'created_by_name',
            'label' => 'LBL_CREATED',
          ),
          1 => 
          array (
            'name' => 'date_modified',
            'comment' => 'Date record last modified',
            'label' => 'LBL_DATE_MODIFIED',
          ),
        ),
        10 => 
        array (
          0 => 
          array (
            'name' => 'verification_data',
            'studio' => 'visible',
            'label' => 'LBL_VERIFICATION_DATA',
          ),
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'mobile_country_code',
            'label' => 'LBL_MOBILE_COUNTRY_CODE',
          ),
          1 => 
          array (
            'name' => 'mobile_number',
            'label' => 'LBL_MOBILE_NUMBER',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'alt_mobile_country_code',
            'label' => 'LBL_ALT_MOBILE_COUNTRY_CODE',
          ),
          1 => 
          array (
            'name' => 'alt_mobile_number',
            'label' => 'LBL_ALT_MOBILE_NUMBER',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'address_unit_number',
            'label' => 'LBL_ADDRESS_UNIT_NUMBER',
          ),
          1 => 
          array (
            'name' => 'address_building_number',
            'label' => 'LBL_ADDRESS_BUILDING_NUMBER',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'address_street',
            'label' => 'LBL_ADDRESS_STREET',
          ),
          1 => 
          array (
            'name' => 'address_district',
            'label' => 'LBL_ADDRESS_DISTRICT',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'address_city',
            'label' => 'LBL_ADDRESS_CITY',
          ),
          1 => 
          array (
            'name' => 'address_country',
            'label' => 'LBL_ADDRESS_COUNTRY',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'address_region',
            'label' => 'LBL_ADDRESS_REGION',
          ),
          1 => 
          array (
            'name' => 'address_zip_code',
            'label' => 'LBL_ADDRESS_ZIP_CODE',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'occupation',
            'label' => 'LBL_OCCUPATION',
          ),
          1 => '',
        ),
      ),
      'lbl_editview_panel2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'employer_name',
            'label' => 'LBL_EMPLOYER_NAME',
          ),
          1 => 
          array (
            'name' => 'employer_mobile',
            'label' => 'LBL_EMPLOYER_MOBILE',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'employer_email',
            'label' => 'LBL_EMPLOYER_EMAIL',
          ),
          1 => 
          array (
            'name' => 'employer_full_address',
            'label' => 'LBL_EMPLOYER_FULL_ADDRESS',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'tax_country',
            'label' => 'LBL_TAX_COUNTRY',
          ),
          1 => 
          array (
            'name' => 'tax_identification_number',
            'label' => 'LBL_TAX_IDENTIFICATION_NUMBER',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'bank_account_holder',
            'label' => 'LBL_BANK_ACCOUNT_HOLDER',
          ),
          1 => 
          array (
            'name' => 'bank_account_number',
            'label' => 'LBL_BANK_ACCOUNT_NUMBER',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'payroll_number',
            'label' => 'LBL_PAYROLL_NUMBER',
          ),
          1 => '',
        ),
      ),
    ),
  ),
);
