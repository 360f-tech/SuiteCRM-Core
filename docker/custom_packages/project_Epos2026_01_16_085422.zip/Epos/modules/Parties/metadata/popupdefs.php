<?php
$popupMeta = array (
    'moduleMain' => 'EPOS_Parties',
    'varName' => 'EPOS_Parties',
    'orderBy' => 'epos_parties.name',
    'whereClauses' => array (
  'name' => 'epos_parties.name',
  'first_name' => 'epos_parties.first_name',
  'last_name' => 'epos_parties.last_name',
  'email' => 'epos_parties.email',
  'mobile_number' => 'epos_parties.mobile_number',
  'assigned_user_id' => 'epos_parties.assigned_user_id',
  'ext_record_id' => 'epos_parties.ext_record_id',
),
    'searchInputs' => array (
  1 => 'name',
  4 => 'first_name',
  5 => 'last_name',
  6 => 'email',
  7 => 'mobile_number',
  8 => 'assigned_user_id',
  9 => 'ext_record_id',
),
    'searchdefs' => array (
  'name' => 
  array (
    'name' => 'name',
    'width' => '10%',
  ),
  'first_name' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_FIRST_NAME',
    'width' => '10%',
    'name' => 'first_name',
  ),
  'last_name' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_LAST_NAME',
    'width' => '10%',
    'name' => 'last_name',
  ),
  'email' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EMAIL',
    'width' => '10%',
    'name' => 'email',
  ),
  'mobile_number' => 
  array (
    'type' => 'phone',
    'label' => 'LBL_MOBILE_NUMBER',
    'width' => '10%',
    'name' => 'mobile_number',
  ),
  'ext_record_id' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EXT_RECORD_ID',
    'width' => '10%',
    'name' => 'ext_record_id',
  ),
  'assigned_user_id' => 
  array (
    'name' => 'assigned_user_id',
    'label' => 'LBL_ASSIGNED_TO',
    'type' => 'enum',
    'function' => 
    array (
      'name' => 'get_user_array',
      'params' => 
      array (
        0 => false,
      ),
    ),
    'width' => '10%',
  ),
),
);
