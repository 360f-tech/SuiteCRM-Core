<?php
$module_name = 'EPOS_Parties';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '20%',
    'default' => true,
  ),
  'GENDER' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_GENDER',
    'width' => '10%',
    'default' => true,
  ),
  'DATE_OF_BIRTH' => 
  array (
    'type' => 'date',
    'label' => 'LBL_DATE_OF_BIRTH',
    'width' => '10%',
    'default' => true,
  ),
  'EMAIL' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EMAIL',
    'width' => '10%',
    'default' => true,
  ),
  'MOBILE_COUNTRY_CODE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_MOBILE_COUNTRY_CODE',
    'width' => '10%',
    'default' => true,
  ),
  'EXT_PARTY_TYPE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EXT_PARTY_TYPE',
    'width' => '10%',
    'default' => true,
  ),
  'MOBILE_NUMBER' => 
  array (
    'type' => 'phone',
    'label' => 'LBL_MOBILE_NUMBER',
    'width' => '10%',
    'default' => true,
  ),
  'DATE_MODIFIED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_MODIFIED',
    'width' => '10%',
    'default' => true,
  ),
  'TITLE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_TITLE',
    'width' => '5%',
    'default' => false,
  ),
  'IS_SMOKER' => 
  array (
    'type' => 'bool',
    'default' => false,
    'label' => 'LBL_IS_SMOKER',
    'width' => '10%',
  ),
  'MARITAL_STATUS' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_MARITAL_STATUS',
    'width' => '10%',
    'default' => false,
  ),
  'ALTERNATE_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_ALTERNATE_NAME',
    'width' => '10%',
    'default' => false,
  ),
  'FIRST_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_FIRST_NAME',
    'width' => '10%',
    'default' => false,
  ),
  'MIDDLE_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_MIDDLE_NAME',
    'width' => '10%',
    'default' => false,
  ),
  'LAST_NAME' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_LAST_NAME',
    'width' => '10%',
    'default' => false,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => false,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'link' => true,
    'type' => 'relate',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'id' => 'ASSIGNED_USER_ID',
    'width' => '10%',
    'default' => false,
  ),
);
