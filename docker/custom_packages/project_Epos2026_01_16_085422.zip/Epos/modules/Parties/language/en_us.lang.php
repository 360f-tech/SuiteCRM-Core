<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2018 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */
$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'Assigned User Id',
  'LBL_ASSIGNED_TO_NAME' => 'Assigned to',
  'LBL_SECURITYGROUPS' => 'Security Groups',
  'LBL_SECURITYGROUPS_SUBPANEL_TITLE' => 'Security Groups',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Date Created',
  'LBL_DATE_MODIFIED' => 'Date Modified',
  'LBL_MODIFIED' => 'Modified By',
  'LBL_MODIFIED_NAME' => 'Modified By Name',
  'LBL_CREATED' => 'Created By',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_DELETED' => 'Deleted',
  'LBL_NAME' => 'Name',
  'LBL_CREATED_USER' => 'Created by User',
  'LBL_MODIFIED_USER' => 'Modified by User',
  'LBL_LIST_NAME' => 'Name',
  'LBL_EDIT_BUTTON' => 'Edit',
  'LBL_REMOVE' => 'Remove',
  'LBL_ASCENDING' => 'Ascending',
  'LBL_DESCENDING' => 'Descending',
  'LBL_OPT_IN' => 'Opt In',
  'LBL_OPT_IN_PENDING_EMAIL_NOT_SENT' => 'Pending Confirm opt in, Confirm opt in not sent',
  'LBL_OPT_IN_PENDING_EMAIL_SENT' => 'Pending Confirm opt in, Confirm opt in sent',
  'LBL_OPT_IN_CONFIRMED' => 'Opted in',
  'LBL_LIST_FORM_TITLE' => 'Parties List',
  'LBL_MODULE_NAME' => 'Parties',
  'LBL_MODULE_TITLE' => 'Parties',
  'LBL_HOMEPAGE_TITLE' => 'My Parties',
  'LNK_NEW_RECORD' => 'Create Parties',
  'LNK_LIST' => 'View Parties',
  'LNK_IMPORT_EPOS_PARTIES' => 'Import Parties',
  'LBL_SEARCH_FORM_TITLE' => 'Search Parties',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activities',
  'LBL_EPOS_PARTIES_SUBPANEL_TITLE' => 'Parties',
  'LBL_NEW_FORM_TITLE' => 'New Parties',
  'LBL_TITLE' => 'Title',
  'LBL_FIRST_NAME' => 'First Name',
  'LBL_MIDDLE_NAME' => 'Middle Name',
  'LBL_LAST_NAME' => 'Last Name',
  'LBL_ALTERNATE_NAME' => 'Alternate Name',
  'LBL_DATE_OF_BIRTH' => 'Date Of Birth',
  'LBL_GENDER' => 'Gender',
  'LBL_NATIONALITY' => 'Nationality',
  'LBL_OTHER_NATIONALITY' => 'Other Nationality',
  'LBL_MARITAL_STATUS' => 'Marital Status',
  'LBL_IDENTIFICATION_TYPE' => 'Identification Type',
  'LBL_IDENTIFICATION_NUMBER' => 'Identification Number',
  'LBL_FATCA_SOCIAL_SECURITY_NUMBER' => 'FATCA Social Security Number',
  'LBL_TAX_COUNTRY' => 'Tax Country',
  'LBL_EMAIL' => 'Email',
  'LBL_MOBILE_COUNTRY_CODE' => 'Mobile Country Code',
  'LBL_MOBILE_NUMBER' => 'Mobile Number',
  'LBL_ALT_MOBILE_COUNTRY_CODE' => 'Alt Mobile Country Code',
  'LBL_ALT_MOBILE_NUMBER' => 'Alt Mobile Number',
  'LBL_ADDRESS_FULL_ADDRESS' => 'Address Full Address',
  'LBL_ADDRESS_UNIT_NUMBER' => 'Address Unit Number',
  'LBL_ADDRESS_BUILDING_NUMBER' => 'Address Building Number',
  'LBL_ADDRESS_STREET' => 'Address Street',
  'LBL_ADDRESS_DISTRICT' => 'Address District',
  'LBL_ADDRESS_CITY' => 'Address City',
  'LBL_ADDRESS_REGION' => 'Address Region',
  'LBL_ADDRESS_COUNTRY' => 'Address Country',
  'LBL_ADDRESS_ZIP_CODE' => 'Address Zip Code',
  'LBL_EMPLOYER_NAME' => 'Employer Name',
  'LBL_EMPLOYER_EMAIL' => 'Employer Email',
  'LBL_EMPLOYER_PHONE' => 'Employer Phone',
  'LBL_TAX_IDENTIFICATION_NUMBER' => 'Tax Identification Number',
  'LBL_COUNTRY_OF_BIRTH' => 'Country Of Birth',
  'LBL_BANK_ACCOUNT_HOLDER' => 'Bank Account Holder',
  'LBL_BANK_ACCOUNT_NUMBER' => 'Bank Account Number',
  'LBL_PAYROLL_NUMBER' => 'Payroll Number',
  'LBL_IS_SMOKER' => 'Is Smoker',
  'LBL_AGE' => 'Age',
  'LBL_EDITVIEW_PANEL1' => 'Correspondence Details',
  'LBL_EDITVIEW_PANEL2' => 'Employment Details',
  'LBL_OCCUPATION' => 'Occupation',
  'LBL_EMPLOYER_FULL_ADDRESS' => 'Employer Full Address',
  'LBL_EMPLOYER_MOBILE' => 'Employer Mobile',
  'LBL_PARTY_SOURCE' => 'Party Source',
  'LBL_EXT_SOURCE' => 'Ext Source',
  'LBL_EXT_RECORD_STATUS' => 'Ext Record Status',
  'LBL_EXT_TENANT_ID' => 'Ext Tenant ID',
  'LBL_EXT_CHANNEL_ID' => 'Ext Channel ID',
  'LBL_EXT_ASSIGNED_TO' => 'Ext Assigned To',
  'LBL_EXT_RECORD_ID' => 'Ext Record ID',
  'LBL_EXT_PUBLIC_ID' => 'Ext Public ID',
  'LBL_EXT_PARTY_TYPE' => 'Ext Party Type',
  'LBL_DATE_OF_BIRTH2' => 'date of birth2',
  'LNK_IMPORT_EPOS_EPOSPARTIES' => 'Import EposParties',
  'LBL_EPOS_EPOSPARTIES_SUBPANEL_TITLE' => 'EposParties',
  'LBL_VERIFICATION_DATA' => 'Verification Data',
);