<?php

class PartiesLogicHook
{

	function before_save(&$bean)
	{
		$nullableFields = ['name'];

		foreach ($nullableFields as $field) {
			if (property_exists($bean, $field)) {
				if ($bean->$field === 'NULL' || $bean->$field === '' || $bean->$field === null) {
					$bean->$field = null;
				}
			}
		}
	}
}
?>